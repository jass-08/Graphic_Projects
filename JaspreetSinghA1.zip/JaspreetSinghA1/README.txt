Hi There,

I didnot know how to implement variables for lighting and shading,

Although, I have directly used my variables from libJim class, there is some commented code to change the shading models

YOu can just uncomment them and they are good to go.

I have done untill vertex Phong + Groraund shading.

Thanks for reading it
